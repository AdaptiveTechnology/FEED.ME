                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1621244
LattePanda centered display stand by Wide is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

I designed this to store my LattePanda and my touch display safely.
The connetion between lattepanda and display seem very thin-skinned so this should make it alot mor durible.

If u have the touch diplay you soon recognize thet the black frams have a different thicknes on each side so i compensated this with this frame. The distance between my frame and toch Field is still 1mm so using the touch is no problem.


The Frame and the Display Backplate nedd to be Pressed together.... depanding on your slicer and printer this takes a bit force. in my case it workes fine and i think it nevver will open spontaneously^^

to mount the latte Panda sefly use a M3x10mm bolt and nut or anything simular in iches ^^

The new STL files are in the orientation i printed them.

At the moment this >Project is done for me. maybe i will later add a cover for the Lattepanda.

# Print Settings

Printer: Da Vinci Pro 1.0 E3DMod
Rafts: No
Supports: No
Resolution: 0,2
Infill: 15%

Notes: 
nothing hard to print here :)

# How I Designed This

## Fusion 360 Share Link

http://a360.co/2dueghn